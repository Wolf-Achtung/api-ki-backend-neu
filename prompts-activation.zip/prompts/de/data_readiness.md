<!-- Data Readiness (DE) -->
<!-- Antworte ausschließlich mit **validem HTML**.
     KEIN <html>, <head> oder <body>. KEINE Markdown-Fences.
     Nutze die Platzhalter:
     - {BRANCHE_LABEL}, {UNTERNEHMENSGROESSE_LABEL}, {BUNDESLAND_LABEL}, {HAUPTLEISTUNG}
     - {report_date}, {report_year}, {kundencode}, {report_id}
     - Optional: {TOOLS_TABLE_HTML}, {FUNDING_TABLE_HTML}, {NEWS_BOX_HTML}
     - KPI/Scores: {score_gesamt}, {score_befaehigung}, {score_governance}, {score_sicherheit}, {score_nutzen}
     Schreibe präzise, fachlich, motivierend – kein Marketing-Sprech. -->

<section class="section data-readiness">
  <h2>Data Readiness</h2>
  <p>Reifegrad der Datenlage (Verfügbarkeit, Qualität, Governance) und konkrete Maßnahmen zur Verbesserung.</p>
</section>

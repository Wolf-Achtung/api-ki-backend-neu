<!-- Empfehlungen (DE) -->
<!-- Antworte ausschließlich mit **validem HTML**.
     KEIN <html>, <head> oder <body>. KEINE Markdown-Fences.
     Nutze die Platzhalter:
     - {BRANCHE_LABEL}, {UNTERNEHMENSGROESSE_LABEL}, {BUNDESLAND_LABEL}, {HAUPTLEISTUNG}
     - {report_date}, {report_year}, {kundencode}, {report_id}
     - Optional: {TOOLS_TABLE_HTML}, {FUNDING_TABLE_HTML}, {NEWS_BOX_HTML}
     - KPI/Scores: {score_gesamt}, {score_befaehigung}, {score_governance}, {score_sicherheit}, {score_nutzen}
     Schreibe präzise, fachlich, motivierend – kein Marketing-Sprech. -->

<section class="section recommendations">
  <h2>Empfehlungen</h2>
  <ul class="bullets">
    <li>Empfehlung 1 (mit Nutzen/ROI‑Hinweis und nächster Aktion)</li>
    <li>Empfehlung 2 (mit Nutzen/ROI‑Hinweis und nächster Aktion)</li>
    <li>Empfehlung 3 (mit Nutzen/ROI‑Hinweis und nächster Aktion)</li>
  </ul>
</section>

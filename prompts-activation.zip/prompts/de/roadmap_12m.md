<!-- Roadmap 12 Monate (DE) -->
<!-- Antworte ausschließlich mit **validem HTML**.
     KEIN <html>, <head> oder <body>. KEINE Markdown-Fences.
     Nutze die Platzhalter:
     - {BRANCHE_LABEL}, {UNTERNEHMENSGROESSE_LABEL}, {BUNDESLAND_LABEL}, {HAUPTLEISTUNG}
     - {report_date}, {report_year}, {kundencode}, {report_id}
     - Optional: {TOOLS_TABLE_HTML}, {FUNDING_TABLE_HTML}, {NEWS_BOX_HTML}
     - KPI/Scores: {score_gesamt}, {score_befaehigung}, {score_governance}, {score_sicherheit}, {score_nutzen}
     Schreibe präzise, fachlich, motivierend – kein Marketing-Sprech. -->

<section class="section roadmap-12m">
  <h2>Roadmap (12 Monate)</h2>
  <p>Quartalsweise Planung mit Zielen, Deliverables, Abhängigkeiten und Messpunkten.</p>
  <ul class="timeline">
    <li><strong>Q1:</strong> …</li>
    <li><strong>Q2:</strong> …</li>
    <li><strong>Q3:</strong> …</li>
    <li><strong>Q4:</strong> …</li>
  </ul>
</section>

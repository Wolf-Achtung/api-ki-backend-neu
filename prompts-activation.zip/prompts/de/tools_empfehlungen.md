<!-- Tool-Empfehlungen (DE) -->
<!-- Antworte ausschließlich mit **validem HTML**.
     KEIN <html>, <head> oder <body>. KEINE Markdown-Fences.
     Nutze die Platzhalter:
     - {BRANCHE_LABEL}, {UNTERNEHMENSGROESSE_LABEL}, {BUNDESLAND_LABEL}, {HAUPTLEISTUNG}
     - {report_date}, {report_year}, {kundencode}, {report_id}
     - Optional: {TOOLS_TABLE_HTML}, {FUNDING_TABLE_HTML}, {NEWS_BOX_HTML}
     - KPI/Scores: {score_gesamt}, {score_befaehigung}, {score_governance}, {score_sicherheit}, {score_nutzen}
     Schreibe präzise, fachlich, motivierend – kein Marketing-Sprech. -->

<section class="section tool-recommendations">
  <h2>Tool‑Empfehlungen & Einführungsreihenfolge</h2>
  <p>Empfohlene Reihenfolge inkl. Integrationshinweisen, Security/DSGVO‑Aspekten und Kostenrahmen.</p>
  <ol>
    <li><strong>Phase 1 (0–30 Tage):</strong> …</li>
    <li><strong>Phase 2 (1–3 Monate):</strong> …</li>
    <li><strong>Phase 3 (3–6 Monate):</strong> …</li>
  </ol>
</section>

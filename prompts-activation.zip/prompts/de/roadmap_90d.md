<!-- Roadmap 90 Tage (DE) -->
<!-- Antworte ausschließlich mit **validem HTML**.
     KEIN <html>, <head> oder <body>. KEINE Markdown-Fences.
     Nutze die Platzhalter:
     - {BRANCHE_LABEL}, {UNTERNEHMENSGROESSE_LABEL}, {BUNDESLAND_LABEL}, {HAUPTLEISTUNG}
     - {report_date}, {report_year}, {kundencode}, {report_id}
     - Optional: {TOOLS_TABLE_HTML}, {FUNDING_TABLE_HTML}, {NEWS_BOX_HTML}
     - KPI/Scores: {score_gesamt}, {score_befaehigung}, {score_governance}, {score_sicherheit}, {score_nutzen}
     Schreibe präzise, fachlich, motivierend – kein Marketing-Sprech. -->

<section class="section roadmap-90d">
  <h2>90‑Tage‑Plan</h2>
  <p>Konkrete Meilensteine für die ersten drei Monate (Ziele, Verantwortliche, Risiken, Next Steps).</p>
  <ol>
    <li><strong>Monat 1:</strong> …</li>
    <li><strong>Monat 2:</strong> …</li>
    <li><strong>Monat 3:</strong> …</li>
  </ol>
</section>
